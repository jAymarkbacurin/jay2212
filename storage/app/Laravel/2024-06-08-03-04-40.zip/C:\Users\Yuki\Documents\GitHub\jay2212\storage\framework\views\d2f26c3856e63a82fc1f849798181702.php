<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <?php
            $success = null;
            if (session('status')) {
                $success = session('status');
            }

        ?>
     <?php $__env->endSlot(); ?>
    <section class="p-3 sm:p-5">
        <div class="mx-auto max-w-screen-xl px-4 lg:px-12">
            <div
                class="bg-slate-900 border-yellow-500 border-[2px] relative shadow-2xl sm:rounded-lg overflow-hidden p-[2rem]">
                <div
                    class="flex flex-col md:flex-row items-center justify-between space-y-3 md:space-y-0 md:space-x-4 p-4 border-b-[2px] border-yellow-500 ">
                    <div class="w-full md:w-1/2">
                        <a href="<?php echo e(route('Runbackup')); ?>">
                            <button type="submit"
                                class="text-yellow-500 hover:text-white mx-[2rem] hover:border-yellow-600 border-slate-900 border-b-[1px] text-center py-[6px] text-[13px] transition ease-in-out delay-150 hover:-translate-y-1 hover:scale-110 duration-300">BACKUP</button>
                        </a>
                        <a href="<?php echo e(route('Runbackup')); ?>">
                            <button type="submit"
                                class="text-yellow-500 hover:text-white hover:border-yellow-600 border-slate-900 border-b-[1px] text-center py-[6px] text-[13px] transition ease-in-out delay-150 hover:-translate-y-1 hover:scale-110 duration-300">RECOVER</button>
                        </a>
                    </div>
                </div>
                <div class="overflow-x-auto">
                    <table class="w-full text-sm text-left ">
                        <thead
                            class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-slate-900 dark:text-gray-400 border-b-[1px] border-yellow-500 rounded-lg">
                        </thead>
                        <tbody>
                            <?php if(count($backups)): ?>
                                <table class="table table-striped table-bordered">
                                    <thead class="thead-dark">
                                        <tr>
                                            <th>File</th>
                                            <th>Size</th>
                                            <th>Date</th>
                                            <th>Age</th>
                                            <th></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $backups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $backup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($backup['file_name']); ?></td>
                                                <td><?php echo e($backup['file_size']); ?></td>
                                                <td><?php echo e(date('d/M/Y, g:ia', strtotime($backup['last_modified']))); ?></td>
                                                <td><?php echo e($backup['last_modified']); ?></td>
                                                <!-- Here we use the diff_date_for_humans function -->
                                                <td class="text-right">
                                                    <a class="btn btn-primary"
                                                        href="<?php echo e(url('backup/download/' . $backup['file_name'])); ?>"><i
                                                            class="fas fa-cloud-download"></i> Download</a>
                                                    <a class="btn btn-xs btn-danger" data-button-type="delete"
                                                        href="<?php echo e(url('backup/delete/' . $backup['file_name'])); ?>"><i
                                                            class="fal fa-trash"></i> Delete</a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            <?php else: ?>
                                <div class="text-center py-5">
                                    <h1 class="text-muted">No existen backups</h1>
                                </div>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Yuki\Documents\GitHub\jay2212\resources\views/backupdetail.blade.php ENDPATH**/ ?>